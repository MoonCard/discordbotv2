var glob = require('glob');
var manager = require('./OSRS.js');
var scores = require('./scores.json');
var fs = require('fs');
var download = require('url-download');
var trivia = require('./trivia.js');
var unirest = require('unirest');
var auth = require('./auth.json');

module.exports = {
	commands: async function (message, vc, homeChannel,bot) {
		if (message.attachments.array().length > 0) {
			dlFile(message.attachments.array()[0]);
		}
		if (message.content.substring(0, 1) == '!') {
			let args = message.content.substring(1).split(' ');
			let cmd = args[0];

			args = args.splice(1)
			switch (cmd) {
				case 'trivtime':
					{
						if (message.member.id == "147441910154264576") {
						  	vc.playFile('./wav/wah.wav');
							let sesh = new trivia.Trivia();
							sesh.request( function (callback) { 
							  trivia.triviaManager(callback,homeChannel,bot);
							});
						}
						break;
					}
				case 'checkem':
					{
						let d1 = Math.floor(Math.random() * 20) + 1;
						let d2 = Math.floor(Math.random() * 20) + 1;
						message.reply('You rolled: ' + d1 + ', ' + d2);
						try {
							if (d1 == d2 && scores.dice.users[message.member.id]) {
								scores.dice.users[message.member.id].dubs = Number(scores.dice.users[message.member.id].dubs) + 1;
								message.reply('You have rolled ' + scores.dice.users[message.member.id].dubs + ' dubs')
								fs.writeFile("scores.json", JSON.stringify(scores), err => console.log(err));
								vc.playFile('C:/Users/quinc/Downloads/Soundboard/impressive.wav');
								if (d1 == 1) {
									vc.playFile('C:/Users/quinc/Downloads/Soundboard/snakeeyes.wav');
								}
							} else if (d1 == d2) {
								scores.dice.users[message.member.id] = {
									"dubs": 1
								};
								fs.writeFile("scores.json", JSON.stringify(scores), err => console.log(err));
								vc.playFile('C:/Users/quinc/Downloads/Soundboard/impressive.wav');
								message.reply('You have rolled ' + scores.dice.users[message.member.id].dubs + ' dubs')
								if (d1 == 1) {
									vc.playFile('C:/Users/quinc/Downloads/Soundboard/snakeeyes.wav');
								}
							}
						} catch (err) {
							console.error(err);
						}
						break;
					}
				case 'getinhere':
					{
						if (message.member.voiceChannel)
							message.member.voiceChannel.join()
							.then(connection => {
								// Connection is an instance of VoiceConnection
								vc = connection;
							})
							.catch(console.log);
						break;
					}
				case 'kick':
					{
						if (vc != null) {
							vc.disconnect();
							vc = null;
						}
						break;
					}
				case 'sb':
					{
						if (vc != null)
							vc.playFile('./wav/' + args[0] + '.wav');
						break;
					}
				case 'help':
					{
						let mess = "Current SB Commands: \n";
						let temp;
						glob.sync('./wav/*.wav').forEach(function (file) {
							temp = file.split("/");
							temp = temp[temp.length - 1].split(".");
							temp = temp[0];
							mess = mess + temp + "\n";
						});
						message.member.createDM().then(channel => channel.send(mess));
						break;
					}
				case 'qall':
					{
						queryAll();
						break;
					}
				case 'hist':
					{
						let string = args.join(' ');
						osrs.ge.getItem(string).then(itm => {
							getGrid(JSON.parse(itm).item.id, JSON.parse(itm).item.name);
						});
						break;
					}
				case 'cleardata':
					{
						wipe();
						break;
					}
				case 'sortData':
					{
						if (args[0] == "margin") {
							ge.sort(compareMargin);
							fs.writeFile("randoms.json", JSON.stringify(ge), err => console.log(err));
						}
					}
				case 'getData':
					{
						if (args[0] == "high_margin") {
							sortData("margin");
							let mess = "";
							for (t = 0; t < 10; t++) {
								mess = mess + "Name: " + ge[t].name + "\nMargin: " + ge[t].margin + "\n";
							}
							message.reply(mess);
						}
						if (args[0] == "low_margin") {
							sortData("margin");
							let mess = "";
							for (t = ge.length - 1; t > ge.length - 11; t--) {
								mess = mess + "Name: " + ge[t].name + "\nMargin: " + ge[t].margin + "\n";
							}
							message.reply(mess);
						}
						if (args[0] == "low_qtymargin") {
							sortData("qtymargin");
							let mess = "";
							for (t = ge.length - 1; t > ge.length - 11; t--) {
								mess = mess + "\nName: " + ge[t].name + "\nQtyMargin: " + (ge[t]["buying-quantity"] - ge[t]["selling-quantity"]) + "\nMargin: " + ge[t].margin;
							}
							message.reply(mess);
						}
						if (args[0] == "high_qtymargin") {
							sortData("qtymargin");
							let mess = "";
							for (t = 0; t < 10; t++) {
								mess = mess + "\nName: " + ge[t].name + "\nQtyMargin: " + (ge[t]["buying-quantity"] - ge[t]["selling-quantity"]) + "\nMargin: " + ge[t].margin;
							}
							message.reply(mess);
						}
					}
				case 'scores':
					{
						if (args[0] == 'dice') {
						  	scores = require('./scores.json');
							let stri = "";
							for (let i in scores.dice.users) {
							  let user = await bot.fetchUser(i);
								stri = stri + "User: " + user.username + " rolled " + scores.dice.users[i].dubs + " dubs\n"
							}
							homeChannel.send(stri);
						}
					  if (args[0] == 'trivia') {
							scores = require('./scores.json');
							let stri = "";
							for (let i in scores.trivia.users) {
							  	let user = await bot.fetchUser(i);
								stri = stri + "User: " + user.username + " guessed " + scores.trivia.users[i].correct + " correct\n"
							}
							homeChannel.send(stri);
						}
						break;
					}
			}
		}
	}
}

async function resolveResult(sesh){
  
}

function dlFile(messageAttachment) {
	console.log('downloading file... ' + messageAttachment.filename);
	let filen = messageAttachment.filename;
	let filet = messageAttachment.filename.split(".");
	filet = filet.splice(1);
	console.log(filet);
	let fileurl = messageAttachment.url;
	if (filet == "wav" || filet == "WAV") {
		download(fileurl, './wav/').on('close', () => {
			console.log("download complete");
		});
	}
	if (filet == "mp3" || filet == "MP3") {
		download(fileurl, './wav/').on('close', () => {
			console.log("download complete");
		});
	}
}
